#include <iostream>
#include <iomanip>

using namespace std;

// Function to check if a year is a leap year
bool isLeapYear(int year) {
    return (year % 4 == 0 && year % 100 != 0) || (year % 400 == 0);
}

// Function to calculate the day of the week for the first day of a month
int calculateDayOfWeek(int year, int month) {
    // Zeller's Congruence algorithm
    if (month < 3) {
        month += 12;
        year--;
    }
    int k = year % 100;
    int j = year / 100;
    int day = 1;

    int h = (day + 13 * (month + 1) / 5 + k + k / 4 + j / 4 - 2 * j) % 7;

    // Convert to 0-based index (0 = Saturday, 1 = Sunday, 2 = Monday, 3 = Tuesday, 4 = Wednesday, 5 = Thursday, 6 = Friday)
    return (h + 6) % 7;
}

// Function to print a calendar for a given year
void printCalendar(int year) {
    const string months[] = {"JANUARY", "FEBRUARY", "MARCH", "APRIL", "MAY", "JUNE",
                             "JULY", "AUGUST", "SEPTEMBER", "OCTOBER", "NOVEMBER", "DECEMBER"};
    const int daysInMonth[] = {31, isLeapYear(year) ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    const string daysOfWeek[] = {"Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"};

    cout << "Enter the year -> " << year << endl;

    for (int month = 0; month < 12; month++) {
        cout << months[month] << " " << year << endl;
        for (const string& dayOfWeek : daysOfWeek) {
            cout << dayOfWeek << " ";
        }
        cout << endl;
        cout << "-----------------------------" << endl;

        int dayOfWeekIndex = calculateDayOfWeek(year, month + 1);

        // Print leading spaces
        for (int i = 0; i < dayOfWeekIndex; i++) {
            cout << "   ";
        }

        // Print the days of the month
        for (int i = 1; i <= daysInMonth[month]; i++) {
            cout << setw(2) << i << " ";
            if ((i + dayOfWeekIndex) % 7 == 0) {
                cout << endl;
            }
        }

        // Print a blank line between months
        cout << endl;
    }
}

int main() {
    int year;
    cout << "Enter a year (after 1900): ";
    cin >> year;

    if (year < 1900) {
        cout << "Please enter a year after 1900." << endl;
    } else {
        printCalendar(year);
    }

    return 0;
}
